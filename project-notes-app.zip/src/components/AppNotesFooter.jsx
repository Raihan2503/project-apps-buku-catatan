import React from "react";

function AppNotesFooter() {
    return (
        <footer>
            <p>&#169; Notes App, By Raihan Alfaridzi Kustiawan</p>
        </footer>
    )
}

export default AppNotesFooter;